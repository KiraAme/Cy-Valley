#ifndef LOCAL_H
    #define LOCAL_H
    
    unsigned long getTimeMicros();
    
    void checkGame (GameData* pGame, int errCode);
    int  checkEvent(GameData* pGame);
    
    
#endif
